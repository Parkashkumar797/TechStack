import React from 'react'

export default function Jobcategories() {
  return (
   <>
<div>
  <h1>Popular Job Categories</h1>
  <div className=''>
    <div>
      <div className="logo"></div>
      <div className="content"></div>
    </div>
    <div>
            <div className="logo"></div>
      <div className="content"></div>
    </div>
    <div>
            <div className="logo"></div>
      <div className="content"></div>
    </div>
    <div>
            <div className="logo"></div>
      <div className="content"></div>
    </div>
  </div>
</div>
   </>
  )
}
